package training.exceptionhandling;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class SaveStudentToFile {

	public void saveToFile(String studentAsString) throws IOException {
		FileWriter myWriter = null;
		try {
			File file = new File("MyStudent.txt");
			myWriter = new FileWriter(file);
			myWriter.write(studentAsString);
		} catch (IOException e) {
			System.out.println("IOException thrown in saveToFile method");
			throw e;
		} finally {
			if (myWriter != null) {
				myWriter.close();
			}
		}
	}

}
